#!/bin/sh

while true; do
	./kaiengine
	sleep 5
done

